/* Home page: the list of tests from questions/data/manifest.js, newest first. */
(async function () {
  const { h } = U;
  const app = document.getElementById("app");
  await Store.init();

  const tests = QBank.manifest().filter((t) => !t.hidden).slice().reverse();
  const row = (t) => {
    const resume = !!localStorage.getItem("ep_active_" + t.id);
    const meta = [t.questions ? `${t.questions} questions` : null, t.minutes ? `${t.minutes} min` : t.minutes === null ? "Untimed" : null].filter(Boolean).join(", ");
    const href = "test.html?id=" + encodeURIComponent(t.id);
    return h("li", { class: "tl__row" },
      h("div", { class: "tl__main" },
        h("h2", { class: "tl__title" }, h("a", { href }, t.title)),
        t.description ? h("p", { class: "tl__desc" }, t.description) : null),
      h("div", { class: "tl__meta" }, meta),
      h("a", { class: "btn" + (resume ? "" : " btn--primary"), href }, resume ? "Resume" : "Start"));
  };

  app.append(Chrome.header("tests"), h("main", { class: "wrap" },
    Chrome.notice(),
    h("h1", { class: "h1" }, "Practice tests"),
    h("p", { class: "lede" }, "Choose a test. You'll enter your name first, then the timer starts."),
    tests.length
      ? h("ul", { class: "tl" }, tests.map(row))
      : h("p", { class: "empty" }, "No tests yet. Add a question file to questions/data and list it in manifest.js.")));
})();
